package library;

import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;

public class LibraryMgmt
{
	private static HashMap<String, Student> studentDetailsMap = new HashMap<>();
	private static HashMap<String, Book> bookDetailsMap = new HashMap<>();
	private static HashMap<String, List<Borrow>> borrowDetailsMap = new HashMap<>();

	public static void main(String[] args)
	{
		loadStudentDetails();
		loadBookDetails();
		while(true)
		{
			System.out.println("1. Search by book name");
			System.out.println("2. Borrow a book");
			System.out.println("3. Return a book");
			System.out.println("4. View book available date");
			System.out.println("5. Admin - View book borrow details");
			System.out.print("Enter your choice:");
			Scanner scanner = new Scanner(System.in);
			int choice = scanner.nextInt();
			switch(choice)
			{
				case 1:
				{
					searchByBookName();
					break;
				}
				case 2:
				{
					borrowBook();
					break;
				}
				case 3:
				{
					returnBook();
					break;
				}
				case 4:
				{
					viewBookAvailableDate();
					break;
				}
				case 5:
				{
					viewBookBorrowDetails();
					break;
				}
			}
		}
	}
	private static void loadStudentDetails()
	{
		// Create 5 Student objects.
		Student[] s = new Student[5];

		// 1st student
		s[0] = new Student();
		String studentId1 = "101";
		s[0].setId(studentId1);
		s[0].setName("Jasmine");
		s[0].setPwd("jasmine");
		studentDetailsMap.put(studentId1, s[0]);

		// 2nd student
		s[1] = new Student();
		String studentId2 = "102";
		s[1].setId(studentId2);
		s[1].setName("Rose");
		s[1].setPwd("rose");
		studentDetailsMap.put(studentId2, s[1]);

		// 3rd student
		s[2] = new Student();
		String studentId3 = "103";
		s[2].setId(studentId3);
		s[2].setName("Lily");
		s[2].setPwd("lily");
		studentDetailsMap.put(studentId3, s[2]);

		// 4th student
		s[3] = new Student();
		String studentId4 = "104";
		s[3].setId(studentId4);
		s[3].setName("Lotus");
		s[3].setPwd("lotus");
		studentDetailsMap.put(studentId4, s[3]);

		// 5th student
		s[4] = new Student();
		String studentId5 = "105";
		s[4].setId(studentId5);
		s[4].setName("Hibiscus");
		s[4].setPwd("hibiscus");
		studentDetailsMap.put(studentId5, s[4]);
	}
	private static void loadBookDetails()
	{
		// Create 5 Book objects.
		Book[] b = new Book[5];

		// 1st book
		b[0] = new Book();
		String bookId1 = "201";
		b[0].setId(bookId1);
		b[0].setName("HTML and XHTML Step by Step");
		b[0].setAuthor("Faithe Wempen");
		int totalNoOfCopiesBook1 = 10;
		b[0].setTotalNoOfCopies(totalNoOfCopiesBook1);
		b[0].setAvailableNoOfCopies(totalNoOfCopiesBook1);
		bookDetailsMap.put(bookId1, b[0]);

		// 2nd book
		b[1] = new Book();
		String bookId2 = "202";
		b[1].setId(bookId2);
		b[1].setName("Using ACT 4");
		b[1].setAuthor("Faithe Wempen");
		int totalNoOfCopiesBook2 = 2;
		b[1].setTotalNoOfCopies(totalNoOfCopiesBook2);
		b[1].setAvailableNoOfCopies(totalNoOfCopiesBook2);
		bookDetailsMap.put(bookId2, b[1]);

		// 3rd book
		b[2] = new Book();
		String bookId3 = "203";
		b[2].setId(bookId3);
		b[2].setName("The Midnight Library");
		b[2].setAuthor("Matt Haig");
		int totalNoOfCopiesBook3 = 4;
		b[2].setTotalNoOfCopies(totalNoOfCopiesBook3);
		b[2].setAvailableNoOfCopies(totalNoOfCopiesBook3);
		bookDetailsMap.put(bookId3, b[2]);

		// 4th book
		b[3] = new Book();
		String bookId4 = "204";
		b[3].setId(bookId4);
		b[3].setName("The Invisible Life of Addie LaRue");
		b[3].setAuthor("V.E. Schwab");
		int totalNoOfCopiesBook4 = 1;
		b[3].setTotalNoOfCopies(totalNoOfCopiesBook4);
		b[3].setAvailableNoOfCopies(totalNoOfCopiesBook4);
		bookDetailsMap.put(bookId4, b[3]);

		// 5th book
		b[4] = new Book();
		String bookId5 = "205";
		b[4].setId(bookId5);
		b[4].setName("The Great Gatsby");
		b[4].setAuthor("F. Scott Fitzgerald");
		int totalNoOfCopiesBook5 = 15;
		b[4].setTotalNoOfCopies(totalNoOfCopiesBook5);
		b[4].setAvailableNoOfCopies(totalNoOfCopiesBook5);
		bookDetailsMap.put(bookId5, b[4]);
	}
	private static void searchByBookName()
	{
		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter book name (Complete book name is not needed.):");
		String bookNameToBeSearched = scanner.nextLine();
		String bookNameToBeSearchedLowerCase = bookNameToBeSearched.toLowerCase();

		int bookInd = 0;
		for(Iterator<String> booksIter = bookDetailsMap.keySet().iterator();booksIter.hasNext();)
		{
			String bookId = booksIter.next();
			Book book = bookDetailsMap.get(bookId);
			String bookName = book.getName();

			if((bookName.toLowerCase()).contains(bookNameToBeSearchedLowerCase))
			{
				bookInd++;

				if(bookInd == 1)
				{
					System.out.println();
				}

				String author = book.getAuthor();
				int totalNoOfCopies = book.getTotalNoOfCopies();
				int availableNoOfCopies = book.getAvailableNoOfCopies();

				System.out.println("DETAILS "+bookInd+":");
				System.out.println("BOOK ID="+bookId);
				System.out.println("BOOK NAME="+bookName);
				System.out.println("AUTHOR NAME="+author);
				System.out.println("TOTAL COPIES="+totalNoOfCopies);
				System.out.println("AVAILABLE COPIES="+availableNoOfCopies);
				System.out.println();
			}
		}
		if(bookInd == 0)
		{
			System.out.println("ERROR: No matches for this book name.");
		}
	}
	private static void borrowBook()
	{
		String bookIdToBeBorrowed = getAndCheckBookIdIsValid();
		if(bookIdToBeBorrowed != null)
		{
			String studentId = getAndCheckStudentIsValid();
			if(studentId != null)
			{
				// Check whether book is available.
				Book book = bookDetailsMap.get(bookIdToBeBorrowed);
				int availableNoOfCopies = book.getAvailableNoOfCopies();
				if(availableNoOfCopies > 0)
				{
					book.setAvailableNoOfCopies(availableNoOfCopies-1);

					Borrow borrow = new Borrow();
					borrow.setBookId(bookIdToBeBorrowed);
					borrow.setStudentId(studentId);
					long currTimeMillis = System.currentTimeMillis();
					borrow.setBorrowTime(currTimeMillis);
					long currTimeMillisPlusOneWeek = currTimeMillis + (7*24*60*60*1000);
					borrow.setReturnTime(currTimeMillisPlusOneWeek);

					if(borrowDetailsMap.containsKey(bookIdToBeBorrowed))
					{ // Few copies of this book are already borrowed.
						List<Borrow> borrowList = borrowDetailsMap.get(bookIdToBeBorrowed);
						borrowList.add(borrow);
					}
					else
					{ // 1st copy of this book is being borrowed now.
						List<Borrow> borrowList = new ArrayList<>();
						borrowList.add(borrow);
						borrowDetailsMap.put(bookIdToBeBorrowed, borrowList);
					}

					System.out.println("SUCCESS: You borrowed this book. You've to return this book before "+ new Date(currTimeMillisPlusOneWeek));
				}
				else
				{
					System.out.println("ERROR: No copies of this book is available now. View book available date for more details.");
				}
			}
		}
	}
	private static String getAndCheckBookIdIsValid()
	{
		Scanner scanner = new Scanner(System.in);

		System.out.print("Enter book id:");
		String bookIdToBeBorrowed = scanner.nextLine();
		// Check whether book_id is valid.
		if(bookDetailsMap.containsKey(bookIdToBeBorrowed))
		{
			return(bookIdToBeBorrowed);
		}
		else
		{
			System.out.println("ERROR: Book id is invalid.");
			return(null);
		}
	}
	private static String getAndCheckStudentIsValid()
	{
		Scanner scanner = new Scanner(System.in);

		// Check whether student_id, student_name, student_password are correct.
		System.out.print("Enter your id:");
		String studentId = scanner.nextLine();

		if(studentDetailsMap.containsKey(studentId))
		{
			System.out.print("Enter your name:");
			String studentName = scanner.nextLine();

			Student student = studentDetailsMap.get(studentId);
			if((student.getName()).equals(studentName))
			{
				System.out.print("Enter your password:");
				String studentPwd = scanner.nextLine();

				if((student.getPwd()).equals(studentPwd))
				{ // student_id, student_name, student_password are correct.
					return(studentId);
				}
				else
				{
					System.out.println("ERROR: Student password is wrong.");
				}
			}
			else
			{
				System.out.println("ERROR: Student name is wrong.");
			}
		}
		else
		{
			System.out.println("ERROR: Student id is invalid.");
		}
		return(null);
	}
	private static boolean getAndCheckAdminIsValid()
	{
		Scanner scanner = new Scanner(System.in);

		// Check whether admin_password is correct.
		System.out.print("Enter admin password:");
		String adminPwd = scanner.nextLine();

		if(adminPwd.equals("admin"))
		{
			return(true);
		}
		else
		{
			System.out.println("ERROR: Admin password is wrong.");
			return(false);
		}
	}
	private static void returnBook()
	{
		String bookIdToBeReturned = getAndCheckBookIdIsValid();
		if(bookIdToBeReturned != null)
		{
			String returningStudentId = getAndCheckStudentIsValid();
			if(returningStudentId != null)
			{
				if(borrowDetailsMap.containsKey(bookIdToBeReturned))
				{
					List<Borrow> borrowList = borrowDetailsMap.get(bookIdToBeReturned);

					int returningStudentBorrowInd = -1, borrowInd = 0;
					long returnTimeMillis = 0;

					for(Borrow borrow : borrowList)
					{
						String studentId = borrow.getStudentId();
						if(studentId.equals(returningStudentId))
						{
							returningStudentBorrowInd = borrowInd;
							returnTimeMillis = borrow.getReturnTime();
							break;
						}
						borrowInd++;
					}

					if(returningStudentBorrowInd != -1)
					{
						borrowList.remove(returningStudentBorrowInd);
						if(borrowList.isEmpty())
						{
							borrowDetailsMap.remove(bookIdToBeReturned);
						}

						Book book = bookDetailsMap.get(bookIdToBeReturned);
						int availableNoOfCopies = book.getAvailableNoOfCopies();
						book.setAvailableNoOfCopies(availableNoOfCopies+1);

						if(System.currentTimeMillis() > returnTimeMillis)
						{
							System.out.println("WARNING: You returned this book. But you've to pay fine, as you're returning after "+new Date(returnTimeMillis));
						}
						else
						{
							System.out.println("SUCCESS: You returned this book.");
						}
					}
					else
					{
						System.out.println("ERROR: The book is not borrowed by you.");
					}
				}
				else
				{
					System.out.println("ERROR: The book is not borrowed.");
				}
			}
		}
	}
	private static void viewBookAvailableDate()
	{
		String bookIdToBeBorrowed = getAndCheckBookIdIsValid();
		if(bookIdToBeBorrowed != null)
		{
			String studentId = getAndCheckStudentIsValid();
			if(studentId != null)
			{
				// Check whether book is already available in library.
				Book book = bookDetailsMap.get(bookIdToBeBorrowed);
				int availableNoOfCopies = book.getAvailableNoOfCopies();
				if(availableNoOfCopies == 0)
				{
					List<Borrow> borrowList = borrowDetailsMap.get(bookIdToBeBorrowed);
					Borrow borrow = borrowList.get(0);
					long returnTimeMillis = borrow.getReturnTime();

					System.out.println("The book will be available after "+(new Date(returnTimeMillis)));
				}
				else if(availableNoOfCopies > 0)
				{
					System.out.println("ERROR: This book is already available in library now.");
				}
			}
		}
	}
	private static void viewBookBorrowDetails()
	{
		String bookIdToBeBorrowed = getAndCheckBookIdIsValid();
		if(bookIdToBeBorrowed != null)
		{
			boolean isAdminValid = getAndCheckAdminIsValid();
			if(isAdminValid)
			{
				if(borrowDetailsMap.containsKey(bookIdToBeBorrowed))
				{
					Book book = bookDetailsMap.get(bookIdToBeBorrowed);
					String bookName = book.getName();
					String author = book.getAuthor();
					System.out.println();
					System.out.println("BOOK NAME="+bookName);
					System.out.println("AUTHOR NAME="+author);
					System.out.println();

					List<Borrow> borrowList = borrowDetailsMap.get(bookIdToBeBorrowed);
					int borrowInd = 0;
					for(Borrow borrow : borrowList)
					{
						borrowInd++;

						String studentId = borrow.getStudentId();
						Student student = studentDetailsMap.get(studentId);
						String studentName = student.getName();

						long borrowTimeMillis = borrow.getBorrowTime();
						long returnTimeMillis = borrow.getReturnTime();

						System.out.println("DETAILS "+borrowInd+":");
						System.out.println("STUDENT ID="+studentId);
						System.out.println("STUDENT NAME="+studentName);
						System.out.println("BORROW TIME="+new Date(borrowTimeMillis));
						System.out.println("RETURN TIME="+new Date(returnTimeMillis));
						System.out.println();
					}
				}
				else
				{
					System.out.println("ERROR: Book is not borrowed by anybody.");
				}
			}
		}
	}
}
