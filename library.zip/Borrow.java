package library;

public class Borrow
{
	private String bookId, studentId;
	private long borrowTime, returnTime;

	public void setBookId(String b)
	{
		bookId = b;
	}
	public void setStudentId(String s)
	{
		studentId = s;
	}
	public void setBorrowTime(long b)
	{
		borrowTime = b;
	}
	public void setReturnTime(long r)
	{
		returnTime = r;
	}
	public String getBookId()
	{
		return(bookId);
	}
	public String getStudentId()
	{
		return(studentId);
	}
	public long getBorrowTime()
	{
		return(borrowTime);
	}
	public long getReturnTime()
	{
		return(returnTime);
	}
}
