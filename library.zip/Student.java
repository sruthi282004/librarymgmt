package library;

public class Student
{
	private String id, name, pwd;

	public void setId(String d)
	{
		id = d;
	}
	public void setName(String n)
	{
		name = n;
	}
	public void setPwd(String p)
	{
		pwd = p;
	}
	public String getId()
	{
		return(id);
	}
	public String getName()
	{
		return(name);
	}
	public String getPwd()
	{
		return(pwd);
	}
}
