package library;

public class Book
{
	private String id, name, author;
	private int totalNoOfCopies, availableNoOfCopies;

	public void setId(String d)
	{
		id = d;
	}
	public void setName(String n)
	{
		name = n;
	}
	public void setAuthor(String a)
	{
		author = a;
	}
	public void setTotalNoOfCopies(int t)
	{
		totalNoOfCopies = t;
	}
	public void setAvailableNoOfCopies(int a)
	{
		availableNoOfCopies = a;
	}
	public String getId()
	{
		return(id);
	}
	public String getName()
	{
		return(name);
	}
	public String getAuthor()
	{
		return(author);
	}
	public int getTotalNoOfCopies()
	{
		return(totalNoOfCopies);
	}
	public int getAvailableNoOfCopies()
	{
		return(availableNoOfCopies);
	}
}
